运行main.py 即可看到效果  
import pygame  
import time  
import sye  
